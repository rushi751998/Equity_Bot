"""Data-quality checks (`tfalgo data check`).

Hard failures exclude a symbol from backtests; soft issues are reported only.
Checks: wrong/naive timezone, duplicate timestamps, bars outside the session, non-positive
prices, OHLC inconsistency, zero-volume streaks, missing in-session bars, missing trading
days (only if a holiday file is loaded), outlier returns, split-like jumps without a recorded
action.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import polars as pl

from tfalgo.calendar import TradingCalendar, timeframe_minutes
from tfalgo.config import QualityConfig

HARD, SOFT = "hard", "soft"
ISSUE_SCHEMA = {"symbol": pl.Utf8, "timeframe": pl.Utf8, "check": pl.Utf8, "severity": pl.Utf8,
                "count": pl.Int64, "first_ts": pl.Utf8, "detail": pl.Utf8}


@dataclass(frozen=True)
class Issue:
    symbol: str
    timeframe: str
    check: str
    severity: str
    count: int
    first_ts: str
    detail: str


class QualityChecker:
    def __init__(self, cfg: QualityConfig, calendar: TradingCalendar, tz: str = "Asia/Kolkata") -> None:
        self.cfg, self.cal, self.tz = cfg, calendar, tz

    def check_symbol(self, symbol: str, bars: pl.DataFrame, timeframe: str = "5m",
                     actions: pl.DataFrame | None = None) -> list[Issue]:
        out: list[Issue] = []

        def add(check: str, sev: str, count: int, first: object, detail: str) -> None:
            if count > 0:
                if isinstance(first, list):
                    first = first[0] if first else ""
                first = first.isoformat() if hasattr(first, "isoformat") else first
                out.append(Issue(symbol, timeframe, check, sev, int(count), str(first), detail))

        if bars.is_empty():
            add("no_data", HARD, 1, "", "no bars")
            return out
        dtype = bars.schema["ts"]
        if getattr(dtype, "time_zone", None) is None:
            add("wrong_timezone", HARD, bars.height, bars["ts"][0], "timestamps are tz-naive")
            return out
        df = bars.sort("ts").with_columns(pl.col("ts").dt.convert_time_zone(self.tz))
        step = timeframe_minutes(timeframe, self.cal.session_minutes)

        # duplicates
        dups = df.height - df["ts"].n_unique()
        add("duplicate_timestamps", HARD, dups, df.filter(df["ts"].is_duplicated())["ts"].head(1).to_list()[:1], "duplicate ts rows")
        df = df.unique("ts", keep="first", maintain_order=True)

        # outside session: post-close bars on days with NO regular bars are special sessions
        # (e.g. Diwali Muhurat) -> soft, ignored by resample. Anything else (pre-open bars,
        # outside bars on a normal day, or too many such days) -> hard (likely timezone/shift).
        o, c = self.cal.session_open, self.cal.session_close
        open_m, close_m = o.hour * 60 + o.minute, c.hour * 60 + c.minute
        mins = pl.col("ts").dt.hour().cast(pl.Int64) * 60 + pl.col("ts").dt.minute().cast(pl.Int64)
        out_mask = (mins < open_m) | (mins >= close_m)
        outside = df.filter(out_mask)
        if outside.height:
            regular_days = set(df.filter(~out_mask)["ts"].dt.date().to_list())
            od = outside.with_columns(_d=pl.col("ts").dt.date(), _m=mins)
            by_day = od.group_by("_d").agg(pl.len().alias("n"), pl.col("_m").min().alias("m0"))
            special = by_day.filter((pl.col("m0") >= close_m) & ~pl.col("_d").is_in(list(regular_days)))
            n_days = max(1, df["ts"].dt.date().n_unique())
            too_many = special.height / n_days > self.cfg.max_special_day_frac
            special_days = [] if too_many else sorted(special["_d"].to_list())
            sp_df = od.filter(pl.col("_d").is_in(special_days))
            hard_df = od.filter(~pl.col("_d").is_in(special_days))
            if sp_df.height:
                near_close = (pl.col("_m") >= close_m) & (pl.col("_m") < close_m + step)
                stray_df = hard_df.filter(near_close)
                hard_df = hard_df.filter(~near_close)
            if stray_df.height:
                add("post_close_stray_bars", SOFT, stray_df.height, stray_df["ts"].head(1).to_list(),
                    "bar stamped within one bar after 15:30 on a normal day; ignored by resample")
            if hard_df.height:
                ex = ", ".join(t.strftime("%Y-%m-%d %H:%M") for t in hard_df["ts"].head(8).to_list())
                add("outside_session", HARD, hard_df.height, hard_df["ts"].head(1).to_list(),
                    f"bars outside 09:15-15:30 on normal days / pre-open; e.g. {ex} "
                    f"(run `tfalgo data outside --symbol {symbol}`)")
        df = df.filter(~out_mask)
        if df.is_empty():
            return out

        # prices
        bad_px = df.filter(pl.any_horizontal(pl.col(["open", "high", "low", "close"]) <= 0)
                           | pl.any_horizontal(pl.col(["open", "high", "low", "close"]).is_null()))
        add("non_positive_price", HARD, bad_px.height, bad_px["ts"].head(1).to_list()[:1], "price <= 0 or null")
        bad_ohlc = df.filter((pl.col("high") < pl.max_horizontal("open", "close", "low"))
                             | (pl.col("low") > pl.min_horizontal("open", "close", "high")))
        add("ohlc_inconsistent", HARD, bad_ohlc.height, bad_ohlc["ts"].head(1).to_list()[:1], "high<low/open/close or low>...")

        # zero-volume streaks
        z = df.with_columns(_z=(pl.col("volume") <= 0)).with_columns(_run=pl.col("_z").rle_id())
        streaks = (z.filter(pl.col("_z")).group_by("_run").agg(pl.len().alias("n"), pl.col("ts").first().alias("t"))
                   .filter(pl.col("n") >= self.cfg.zero_volume_streak_bars))
        add("zero_volume_streak", SOFT, streaks.height, streaks["t"].min() if streaks.height else "",
            f"runs >= {self.cfg.zero_volume_streak_bars} bars; longest {streaks['n'].max() if streaks.height else 0}")

        # missing bars (per day present in the data) and missing days
        daily = df.group_by(pl.col("ts").dt.date().alias("d")).agg(pl.len().alias("n")).sort("d")
        expected_per_day = len(self.cal.expected_bar_starts(daily["d"][0], timeframe))
        missing = (expected_per_day - daily["n"]).clip(lower_bound=0)
        total_missing = int(missing.sum())
        worst = daily.with_columns(m=expected_per_day - pl.col("n")).sort("m", descending=True).head(1)
        frac = total_missing / max(1, expected_per_day * daily.height)
        add("missing_bars", HARD if frac > self.cfg.max_missing_bar_frac else SOFT, total_missing,
            daily.filter(pl.Series(missing) > 0)["d"].head(1).to_list()[:1],
            f"{frac:.2%} of expected bars; worst day {worst['d'][0]} ({worst['m'][0]} missing)")
        if self.cal.strict:
            expected_days = set(self.cal.trading_days(daily["d"].min(), daily["d"].max()))
            gone = sorted(expected_days - set(daily["d"].to_list()))
            add("missing_trading_days", SOFT, len(gone), gone[:1], f"{len(gone)} calendar trading days without bars")

        # outlier returns
        same_day = pl.col("ts").dt.date() == pl.col("ts").dt.date().shift(1)
        r = (pl.col("close") / pl.col("close").shift(1) - 1).abs()
        ob = df.filter(same_day & (r > self.cfg.outlier_bar_return))
        add("outlier_bar_return", SOFT, ob.height, ob["ts"].head(1).to_list()[:1], f"|bar return| > {self.cfg.outlier_bar_return:.0%}")

        # daily close-to-close: outliers and split-like jumps
        dc = (df.group_by(pl.col("ts").dt.date().alias("d"), maintain_order=True).agg(pl.col("close").last())
              .with_columns(prev=pl.col("close").shift(1)).drop_nulls("prev")
              .with_columns(ratio=pl.col("prev") / pl.col("close")))
        action_days = set(actions["ex_date"].to_list()) if actions is not None and not actions.is_empty() else set()

        def near_action(d) -> bool:  # noqa: ANN001
            return any(abs((d - a).days) <= 2 for a in action_days)

        big = dc.filter((pl.col("close") / pl.col("prev") - 1).abs() > self.cfg.outlier_daily_return)
        big = big.filter(pl.Series([not near_action(d) for d in big["d"]], dtype=pl.Boolean)) if big.height else big
        add("outlier_daily_return", SOFT, big.height, big["d"].head(1).to_list()[:1], f"|daily return| > {self.cfg.outlier_daily_return:.0%} without action")

        tol = self.cfg.split_jump_tolerance
        cand = []
        for d, ratio in zip(dc["d"], dc["ratio"], strict=True):
            for k in self.cfg.split_jump_ratios:
                if (abs(ratio / k - 1) < tol or abs(ratio * k - 1) < tol) and not near_action(d):
                    cand.append(d)
                    break
        add("split_like_jump", HARD if self.cfg.split_jump_severity == "hard" else SOFT, len(cand),
            cand[:1], "daily close jumped by a split-like ratio with no recorded corporate action")
        return out

    def run(self, frames: dict[str, pl.DataFrame], timeframe: str = "5m",
            actions: dict[str, pl.DataFrame] | None = None) -> pl.DataFrame:
        rows: list[Issue] = []
        for sym, bars in frames.items():
            rows += self.check_symbol(sym, bars, timeframe, (actions or {}).get(sym))
        if not rows:
            return pl.DataFrame(schema=ISSUE_SCHEMA)
        return pl.DataFrame([r.__dict__ for r in rows], schema=ISSUE_SCHEMA)


def hard_failed_symbols(issues: pl.DataFrame) -> dict[str, list[str]]:
    h = issues.filter(pl.col("severity") == HARD)
    return {s: g["check"].to_list() for (s,), g in h.group_by("symbol")}


def write_report(issues: pl.DataFrame, symbols: list[str], outdir: str | Path) -> Path:
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    issues.write_csv(out / "quality_report.csv")
    failed = hard_failed_symbols(issues)
    lines = [f"# Data quality report ({datetime.now():%Y-%m-%d %H:%M})", "",
             f"Symbols checked: {len(symbols)}; excluded (hard failures): {len(failed)}", ""]
    for s in symbols:
        sub = issues.filter(pl.col("symbol") == s)
        status = "EXCLUDED" if s in failed else "ok"
        lines.append(f"## {s}: {status}")
        for r in sub.iter_rows(named=True):
            lines.append(f"- [{r['severity']}] {r['check']} x{r['count']} (first {r['first_ts']}): {r['detail']}")
        lines.append("")
    path = out / "quality_summary.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path
