"""Bar storage behind an abstract interface.

Stage 1 uses SQLite (stdlib). To move to Parquet/DuckDB/Postgres later, implement `BarStore`
and register it in `STORES`; nothing else changes. Raw bars are never overwritten: existing
(symbol, timeframe, ts) rows are kept and differing re-ingests are reported as conflicts.
"""

from __future__ import annotations

import sqlite3
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

import polars as pl

from tfalgo.data.schema import BAR_COLUMNS, empty_actions, empty_bars
from tfalgo.registry import Registry

DateRange = tuple[date, date]


@dataclass(frozen=True)
class WriteResult:
    inserted: int
    identical: int
    conflicts: int


def merge_ranges(ranges: list[DateRange]) -> list[DateRange]:
    """Merge overlapping/adjacent (inclusive) date ranges."""
    out: list[DateRange] = []
    for s, e in sorted(ranges):
        if out and s <= out[-1][1].fromordinal(out[-1][1].toordinal() + 1):
            out[-1] = (out[-1][0], max(out[-1][1], e))
        else:
            out.append((s, e))
    return out


class BarStore(ABC):
    @abstractmethod
    def write_bars(self, symbol: str, timeframe: str, bars: pl.DataFrame) -> WriteResult: ...
    @abstractmethod
    def read_bars(self, symbol: str, timeframe: str, start: date | None = None,
                  end: date | None = None) -> pl.DataFrame: ...
    @abstractmethod
    def list_symbols(self, timeframe: str) -> list[str]: ...
    @abstractmethod
    def covered_ranges(self, symbol: str, timeframe: str) -> list[DateRange]: ...
    @abstractmethod
    def mark_covered(self, symbol: str, timeframe: str, start: date, end: date) -> None: ...
    @abstractmethod
    def write_corporate_actions(self, symbol: str, actions: pl.DataFrame) -> None: ...
    @abstractmethod
    def read_corporate_actions(self, symbol: str) -> pl.DataFrame: ...
    @abstractmethod
    def write_adj_factors(self, symbol: str, factors: pl.DataFrame) -> None: ...
    @abstractmethod
    def read_adj_factors(self, symbol: str) -> pl.DataFrame: ...


STORES: Registry[BarStore] = Registry("bar store")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS bars_raw(
  symbol TEXT NOT NULL, timeframe TEXT NOT NULL, ts INTEGER NOT NULL,
  open REAL, high REAL, low REAL, close REAL, volume REAL,
  PRIMARY KEY(symbol, timeframe, ts)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS manifest(
  symbol TEXT NOT NULL, timeframe TEXT NOT NULL, start TEXT NOT NULL, end TEXT NOT NULL,
  PRIMARY KEY(symbol, timeframe, start));
CREATE TABLE IF NOT EXISTS corporate_actions(
  symbol TEXT NOT NULL, ex_date TEXT NOT NULL, type TEXT NOT NULL, ratio REAL NOT NULL,
  PRIMARY KEY(symbol, ex_date, type));
CREATE TABLE IF NOT EXISTS adj_factor(
  symbol TEXT NOT NULL, ex_date TEXT NOT NULL, cum_factor REAL NOT NULL,
  PRIMARY KEY(symbol, ex_date));
"""


@STORES.register("sqlite")
class SqliteBarStore(BarStore):
    def __init__(self, path: str | Path = ":memory:", tz: str = "Asia/Kolkata") -> None:
        if str(path) != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.tz = tz
        self._db = sqlite3.connect(str(path))
        self._db.executescript(_SCHEMA)

    def close(self) -> None:
        self._db.close()

    # -- bars ---------------------------------------------------------------------
    def write_bars(self, symbol: str, timeframe: str, bars: pl.DataFrame) -> WriteResult:
        if bars.is_empty():
            return WriteResult(0, 0, 0)
        df = bars.select(BAR_COLUMNS).with_columns(_e=pl.col("ts").dt.epoch("s")).unique("_e", keep="first")
        lo, hi = df["_e"].min(), df["_e"].max()
        cur = self._db.execute(
            "SELECT ts, open, high, low, close, volume FROM bars_raw "
            "WHERE symbol=? AND timeframe=? AND ts BETWEEN ? AND ?", (symbol, timeframe, lo, hi))
        existing = pl.DataFrame(cur.fetchall(), schema=["_e", "eo", "eh", "el", "ec", "ev"], orient="row")
        new = df
        identical = conflicts = 0
        if not existing.is_empty():
            j = df.join(existing, on="_e", how="inner")
            same = (
                ((j["open"] - j["eo"]).abs() < 1e-9) & ((j["high"] - j["eh"]).abs() < 1e-9)
                & ((j["low"] - j["el"]).abs() < 1e-9) & ((j["close"] - j["ec"]).abs() < 1e-9)
                & ((j["volume"] - j["ev"]).abs() < 1e-9)
            )
            identical, conflicts = int(same.sum()), int((~same).sum())
            new = df.join(existing.select("_e"), on="_e", how="anti")
        rows = [
            (symbol, timeframe, e, o, h, l, c, v)
            for e, o, h, l, c, v in new.select("_e", "open", "high", "low", "close", "volume").iter_rows()
        ]
        with self._db:
            self._db.executemany("INSERT OR IGNORE INTO bars_raw VALUES(?,?,?,?,?,?,?,?)", rows)
        return WriteResult(len(rows), identical, conflicts)

    def read_bars(self, symbol: str, timeframe: str, start: date | None = None,
                  end: date | None = None) -> pl.DataFrame:
        q = "SELECT ts, open, high, low, close, volume FROM bars_raw WHERE symbol=? AND timeframe=?"
        args: list[object] = [symbol, timeframe]
        if start:
            q += " AND ts >= ?"
            args.append(int(datetime.combine(start, datetime.min.time(), tzinfo=_tz(self.tz)).timestamp()))
        if end:
            q += " AND ts < ?"
            e = datetime.combine(end, datetime.min.time(), tzinfo=_tz(self.tz))
            args.append(int(e.timestamp()) + 86400)
        rows = self._db.execute(q + " ORDER BY ts", args).fetchall()
        if not rows:
            return empty_bars(self.tz)
        df = pl.DataFrame(rows, schema=["ts", "open", "high", "low", "close", "volume"], orient="row")
        return df.with_columns(
            pl.from_epoch("ts", time_unit="s").dt.cast_time_unit("us")
            .dt.replace_time_zone("UTC").dt.convert_time_zone(self.tz)
        )

    def list_symbols(self, timeframe: str) -> list[str]:
        cur = self._db.execute("SELECT DISTINCT symbol FROM bars_raw WHERE timeframe=? ORDER BY 1", (timeframe,))
        return [r[0] for r in cur.fetchall()]

    # -- manifest -----------------------------------------------------------------
    def covered_ranges(self, symbol: str, timeframe: str) -> list[DateRange]:
        cur = self._db.execute("SELECT start, end FROM manifest WHERE symbol=? AND timeframe=?", (symbol, timeframe))
        return merge_ranges([(date.fromisoformat(s), date.fromisoformat(e)) for s, e in cur.fetchall()])

    def mark_covered(self, symbol: str, timeframe: str, start: date, end: date) -> None:
        merged = merge_ranges(self.covered_ranges(symbol, timeframe) + [(start, end)])
        with self._db:
            self._db.execute("DELETE FROM manifest WHERE symbol=? AND timeframe=?", (symbol, timeframe))
            self._db.executemany(
                "INSERT INTO manifest VALUES(?,?,?,?)",
                [(symbol, timeframe, s.isoformat(), e.isoformat()) for s, e in merged])

    # -- corporate actions / factors ------------------------------------------------
    def write_corporate_actions(self, symbol: str, actions: pl.DataFrame) -> None:
        rows = [(symbol, d.isoformat(), t, r) for d, t, r in actions.select("ex_date", "type", "ratio").iter_rows()]
        with self._db:
            self._db.executemany("INSERT OR REPLACE INTO corporate_actions VALUES(?,?,?,?)", rows)

    def read_corporate_actions(self, symbol: str) -> pl.DataFrame:
        rows = self._db.execute(
            "SELECT ex_date, type, ratio FROM corporate_actions WHERE symbol=? ORDER BY ex_date", (symbol,)).fetchall()
        if not rows:
            return empty_actions()
        return pl.DataFrame(rows, schema=["ex_date", "type", "ratio"], orient="row").with_columns(
            pl.col("ex_date").str.to_date())

    def write_adj_factors(self, symbol: str, factors: pl.DataFrame) -> None:
        with self._db:
            self._db.execute("DELETE FROM adj_factor WHERE symbol=?", (symbol,))
            self._db.executemany(
                "INSERT INTO adj_factor VALUES(?,?,?)",
                [(symbol, d.isoformat(), f) for d, f in factors.select("ex_date", "cum_factor").iter_rows()])

    def read_adj_factors(self, symbol: str) -> pl.DataFrame:
        rows = self._db.execute(
            "SELECT ex_date, cum_factor FROM adj_factor WHERE symbol=? ORDER BY ex_date", (symbol,)).fetchall()
        if not rows:
            return pl.DataFrame(schema={"ex_date": pl.Date, "cum_factor": pl.Float64})
        return pl.DataFrame(rows, schema=["ex_date", "cum_factor"], orient="row").with_columns(
            pl.col("ex_date").str.to_date())


def _tz(name: str):  # noqa: ANN202
    from zoneinfo import ZoneInfo
    return ZoneInfo(name)
