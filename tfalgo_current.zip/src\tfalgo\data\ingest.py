"""Idempotent, incremental ingestion: provider -> store, tracked by a coverage manifest."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, timedelta

from tfalgo.data.adjust import compute_factors
from tfalgo.data.provider import DataProvider
from tfalgo.data.store import BarStore, DateRange, merge_ranges
from tfalgo.retry import retry

log = logging.getLogger(__name__)


def subtract_ranges(requested: DateRange, covered: list[DateRange]) -> list[DateRange]:
    """Parts of `requested` (inclusive) not covered by `covered`."""
    gaps: list[DateRange] = []
    cur = requested[0]
    one = timedelta(days=1)
    for s, e in merge_ranges(covered):
        if e < cur or s > requested[1]:
            continue
        if s > cur:
            gaps.append((cur, s - one))
        cur = max(cur, e + one)
        if cur > requested[1]:
            break
    if cur <= requested[1]:
        gaps.append((cur, requested[1]))
    return gaps


@dataclass
class IngestReport:
    symbol: str
    timeframe: str
    fetched: list[DateRange] = field(default_factory=list)
    inserted: int = 0
    identical: int = 0
    conflicts: int = 0
    skipped_reason: str | None = None


class IngestService:
    def __init__(self, provider: DataProvider, store: BarStore, retry_attempts: int = 5) -> None:
        self.provider, self.store = provider, store
        self._fetch = retry(max_attempts=retry_attempts, exceptions=(ConnectionError, TimeoutError))(self._fetch_raw)

    def _fetch_raw(self, symbol: str, timeframe: str, start: date, end: date, is_index: bool):  # noqa: ANN202
        if is_index:
            return self.provider.get_index_ohlcv(symbol, timeframe, start, end)
        return self.provider.get_ohlcv(symbol, timeframe, start, end, adjusted=False)

    def ingest(self, symbol: str, timeframe: str, start: date, end: date, is_index: bool = False) -> IngestReport:
        key = f"idx:{symbol}" if is_index else symbol
        rep = IngestReport(key, timeframe)
        gaps = subtract_ranges((start, end), self.store.covered_ranges(key, timeframe))
        for g_start, g_end in gaps:
            try:
                bars = self._fetch(symbol, timeframe, g_start, g_end, is_index)
            except FileNotFoundError as exc:
                rep.skipped_reason = str(exc)
                log.warning("skip %s: %s", key, exc)
                return rep
            res = self.store.write_bars(key, timeframe, bars)
            rep.inserted += res.inserted
            rep.identical += res.identical
            rep.conflicts += res.conflicts
            if not bars.is_empty():  # empty fetch is not marked covered so it is retried
                self.store.mark_covered(key, timeframe, g_start, g_end)
                rep.fetched.append((g_start, g_end))
        if not is_index:
            actions = self.provider.get_corporate_actions(symbol, start, end)
            if not actions.is_empty():
                self.store.write_corporate_actions(symbol, actions)
                self.store.write_adj_factors(symbol, compute_factors(self.store.read_corporate_actions(symbol)))
        if rep.conflicts:
            log.warning("%s: %d re-ingested bars differ from stored raw bars (kept stored)", key, rep.conflicts)
        return rep
