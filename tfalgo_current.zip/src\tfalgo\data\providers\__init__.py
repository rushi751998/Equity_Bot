"""Importing this package registers the built-in providers."""

from tfalgo.data.providers import csv_provider, stubs  # noqa: F401
