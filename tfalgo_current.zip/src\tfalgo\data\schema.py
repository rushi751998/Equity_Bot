"""Canonical bar schema shared by all providers/stores."""

from __future__ import annotations

import polars as pl

BAR_COLUMNS = ["ts", "open", "high", "low", "close", "volume"]


def empty_bars(tz: str = "Asia/Kolkata") -> pl.DataFrame:
    return pl.DataFrame(
        schema={
            "ts": pl.Datetime("us", tz),
            "open": pl.Float64,
            "high": pl.Float64,
            "low": pl.Float64,
            "close": pl.Float64,
            "volume": pl.Float64,
        }
    )


CORP_ACTION_SCHEMA = {"ex_date": pl.Date, "type": pl.Utf8, "ratio": pl.Float64}


def empty_actions() -> pl.DataFrame:
    return pl.DataFrame(schema=CORP_ACTION_SCHEMA)
