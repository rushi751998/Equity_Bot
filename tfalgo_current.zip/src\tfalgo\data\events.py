"""Event provider (results dates, corporate-action dates).

v1 is chart-only: the default is `NullEventProvider` (no events => event vetoes/penalties are
inactive). A CSV provider and the date-window blackout heuristic are included for later.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date, timedelta
from pathlib import Path

import polars as pl

from tfalgo.calendar import TradingCalendar
from tfalgo.registry import Registry


class EventProvider(ABC):
    @abstractmethod
    def event_dates(self, symbol: str) -> set[date]: ...

    def is_event_day(self, symbol: str, d: date) -> bool:
        return d in self.event_dates(symbol)

    def has_event_within(self, symbol: str, d: date, n_trading_days: int, cal: TradingCalendar) -> bool:
        """Any event on trading days d+1 .. d+n (never uses days <= d knowledge beyond the schedule)."""
        cur = d
        for _ in range(n_trading_days):
            cur = cal.next_trading_day(cur)
            if self.is_event_day(symbol, cur):
                return True
        return False


EVENTS: Registry[EventProvider] = Registry("event provider")


@EVENTS.register("none")
class NullEventProvider(EventProvider):
    def event_dates(self, symbol: str) -> set[date]:
        return set()


@EVENTS.register("csv")
class CsvEventProvider(EventProvider):
    """CSV with columns: symbol,date."""

    def __init__(self, path: str | Path) -> None:
        df = pl.read_csv(path).with_columns(pl.col("date").str.to_date())
        self._by_symbol = {s: set(g["date"].to_list()) for (s,), g in df.group_by("symbol")}

    def event_dates(self, symbol: str) -> set[date]:
        return self._by_symbol.get(symbol, set())


@EVENTS.register("blackout")
class BlackoutEventProvider(EventProvider):
    """Heuristic: +/- n calendar days around typical result windows (mid-Jan..mid-Feb, etc.)."""

    WINDOWS = [((1, 15), (2, 14)), ((4, 15), (5, 15)), ((7, 15), (8, 14)), ((10, 15), (11, 14))]

    def __init__(self, blackout_days: int = 3) -> None:
        self.n = blackout_days

    def event_dates(self, symbol: str) -> set[date]:  # not enumerable; use is_event_day
        return set()

    def is_event_day(self, symbol: str, d: date) -> bool:
        for (m1, d1), (m2, d2) in self.WINDOWS:
            lo = date(d.year, m1, d1) - timedelta(days=self.n)
            hi = date(d.year, m2, d2) + timedelta(days=self.n)
            if lo <= d <= hi:
                return True
        return False
