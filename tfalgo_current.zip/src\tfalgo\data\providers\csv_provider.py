"""CSV provider: one file per symbol with columns date,open,high,low,close,volume.

Handles the pandas-style export (unnamed index column, ISO timestamps with +05:30 offset).
Bar timestamp = bar START time. Finer-than-native timeframes are not available; coarser ones
are produced by exchange-anchored resampling (graceful degradation, spec 5.3).
"""

from __future__ import annotations

import logging
import re
from datetime import date
from pathlib import Path

import polars as pl

from tfalgo.config import CsvProviderConfig
from tfalgo.calendar import timeframe_minutes
from tfalgo.data.adjust import adjust_bars
from tfalgo.data.provider import PROVIDERS, DataProvider, Instrument
from tfalgo.data.resample import resample
from tfalgo.data.schema import BAR_COLUMNS, empty_actions, empty_bars

log = logging.getLogger(__name__)
_HAS_OFFSET = re.compile(r"(Z|[+-]\d{2}:?\d{2})$")


@PROVIDERS.register("csv")
class CsvProvider(DataProvider):
    name = "csv"

    def __init__(self, cfg: CsvProviderConfig, tz: str = "Asia/Kolkata") -> None:
        self.cfg, self.tz = cfg, tz
        self._cache: dict[Path, pl.DataFrame] = {}

    # -- helpers --------------------------------------------------------------------
    def _path(self, pattern: str, **kw: str) -> Path:
        return self.cfg.root / pattern.format(**kw)

    def _load(self, path: Path) -> pl.DataFrame:
        if path in self._cache:
            return self._cache[path]
        if not path.exists():
            raise FileNotFoundError(f"Data file not found: {path}")
        c = self.cfg.columns
        raw = pl.read_csv(path, infer_schema_length=10_000)
        missing = [x for x in (c.ts, c.open, c.high, c.low, c.close, c.volume) if x not in raw.columns]
        if missing:
            raise ValueError(f"{path}: missing columns {missing}; found {raw.columns}")
        df = raw.select(
            pl.col(c.ts).cast(pl.Utf8).alias("ts"),
            pl.col(c.open).cast(pl.Float64).alias("open"),
            pl.col(c.high).cast(pl.Float64).alias("high"),
            pl.col(c.low).cast(pl.Float64).alias("low"),
            pl.col(c.close).cast(pl.Float64).alias("close"),
            pl.col(c.volume).cast(pl.Float64).alias("volume"),
        )
        sample = df["ts"].drop_nulls().head(1).to_list()
        if sample and _HAS_OFFSET.search(sample[0].strip()):
            ts = pl.col("ts").str.to_datetime("%Y-%m-%d %H:%M:%S%z", time_unit="us").dt.convert_time_zone(self.tz)
        else:
            naive_tz = self.cfg.naive_timestamps_tz
            if naive_tz is None:
                raise ValueError(f"{path}: timestamps have no UTC offset; set data.csv.naive_timestamps_tz")
            ts = pl.col("ts").str.to_datetime("%Y-%m-%d %H:%M:%S", time_unit="us").dt.replace_time_zone(naive_tz).dt.convert_time_zone(self.tz)
        out = df.with_columns(ts.alias("ts")).select(BAR_COLUMNS).sort("ts")
        self._cache[path] = out
        return out

    def _slice(self, df: pl.DataFrame, start: date, end: date) -> pl.DataFrame:
        d = pl.col("ts").dt.date()
        return df.filter((d >= start) & (d <= end))

    def _serve(self, df, timeframe, start, end, native_tf=None):
        native_tf = native_tf or self.cfg.native_timeframe
        native = timeframe_minutes(native_tf)
        if timeframe == native_tf:
            return self._slice(df, start, end)
        if timeframe != "1D" and timeframe_minutes(timeframe) < native:
            raise ValueError(f"{timeframe} is finer than native {self.cfg.native_timeframe}")
        rs = resample(df, timeframe, base_minutes=native, tz=self.tz).drop("bar_end", "n_bars")
        return self._slice(rs, start, end)

    # -- DataProvider -----------------------------------------------------------------
    def list_instruments(self) -> list[Instrument]:
        if self.cfg.instruments_file and Path(self.cfg.instruments_file).exists():
            df = pl.read_csv(self.cfg.instruments_file)
            return [Instrument(r["symbol"], r.get("isin"), r.get("exchange") or "NSE", r.get("sector"))
                    for r in df.iter_rows(named=True)]
        glob = self.cfg.symbol_pattern.format(symbol="*")
        rx = re.compile("^" + re.escape(self.cfg.symbol_pattern).replace(r"\{symbol\}", "(.+)") + "$")
        out = []
        for p in sorted(self.cfg.root.glob(glob)):
            m = rx.match(p.name)
            if m:
                out.append(Instrument(m.group(1)))
        return out

    def get_ohlcv(self, symbol: str, timeframe: str, start: date, end: date, adjusted: bool = False) -> pl.DataFrame:
        df = self._load(self._path(self.cfg.symbol_pattern, symbol=symbol))
        if adjusted:
            actions = self.get_corporate_actions(symbol, date.min, date.max)
            df = adjust_bars(df, actions)
        return self._serve(df, timeframe, start, end) if not df.is_empty() else empty_bars(self.tz)

    def get_corporate_actions(self, symbol: str, start: date, end: date) -> pl.DataFrame:
        f = self.cfg.corporate_actions_file
        if not f or not Path(f).exists():
            return empty_actions()
        df = pl.read_csv(f).filter(pl.col("symbol") == symbol)
        if df.is_empty():
            return empty_actions()
        return (df.with_columns(pl.col("ex_date").str.to_date(), pl.col("ratio").cast(pl.Float64))
                .filter((pl.col("ex_date") >= start) & (pl.col("ex_date") <= end))
                .select("ex_date", "type", "ratio"))

    def get_index_ohlcv(self, index: str, timeframe: str, start: date, end: date) -> pl.DataFrame:
        df = self._load(self._path(self.cfg.index_pattern, index=index))
        return self._serve(df, timeframe, start, end, native_tf=self.cfg.index_native_timeframe)

    def native_timeframe(self, symbol: str) -> str:
        return self.cfg.native_timeframe
