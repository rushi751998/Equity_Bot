"""Documented broker-provider stubs (Kite / Upstox / Dhan).

Not implemented in stage 1. `BrokerProviderBase` supplies the scaffolding every real broker
adapter needs: auth hook, rate limiting, retry/backoff. Subclass, implement `_fetch_*`, and
register with `PROVIDERS`.

TODO(prod): token refresh, pagination of intraday history (vendors cap candles per call),
instrument-token lookup, corporate-action source, and symbol mapping to NSE tradingsymbols.
"""

from __future__ import annotations

from datetime import date

import polars as pl

from tfalgo.data.provider import PROVIDERS, DataProvider, Instrument
from tfalgo.retry import RateLimiter, retry


class BrokerProviderBase(DataProvider):
    calls_per_sec: float = 3.0
    max_attempts: int = 5

    def __init__(self, **credentials: str) -> None:
        self.credentials = credentials
        self._limiter = RateLimiter(self.calls_per_sec)
        self.authenticate()

    def authenticate(self) -> None:  # TODO: vendor login / token refresh
        raise NotImplementedError

    def _call(self, fn, *args, **kwargs):  # noqa: ANN001, ANN202
        """Rate-limited, retried vendor call."""
        @retry(max_attempts=self.max_attempts)
        def run():  # noqa: ANN202
            self._limiter.wait()
            return fn(*args, **kwargs)
        return run()

    def list_instruments(self) -> list[Instrument]:
        raise NotImplementedError

    def get_ohlcv(self, symbol: str, timeframe: str, start: date, end: date, adjusted: bool = False) -> pl.DataFrame:
        raise NotImplementedError

    def get_corporate_actions(self, symbol: str, start: date, end: date) -> pl.DataFrame:
        raise NotImplementedError

    def get_index_ohlcv(self, index: str, timeframe: str, start: date, end: date) -> pl.DataFrame:
        raise NotImplementedError


@PROVIDERS.register("kite")
class KiteProvider(BrokerProviderBase):
    """Zerodha Kite Connect (historical API: ~2000 days/call for daily, 60 days for minute)."""
    name = "kite"


@PROVIDERS.register("upstox")
class UpstoxProvider(BrokerProviderBase):
    name = "upstox"


@PROVIDERS.register("dhan")
class DhanProvider(BrokerProviderBase):
    name = "dhan"
