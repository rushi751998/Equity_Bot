"""Corporate-action adjustment (splits / bonus). Raw prices are never modified.

`ratio` = new shares per old share (5-for-1 split => 5; 1:1 bonus => 2).
Backward adjustment: bars BEFORE an ex-date are multiplied by 1/ratio (price) and by ratio
(volume). Dividend adjustment is off. Indicators use adjusted series; sizing, fills, costs and
P&L use raw prices (spec section 2).
"""

from __future__ import annotations

import polars as pl

from tfalgo.data.schema import empty_actions

VALID_TYPES = {"split", "bonus"}


def normalize_actions(actions: pl.DataFrame) -> pl.DataFrame:
    if actions.is_empty():
        return empty_actions()
    bad = actions.filter(~pl.col("type").is_in(list(VALID_TYPES)) | (pl.col("ratio") <= 0))
    if not bad.is_empty():
        raise ValueError(f"Invalid corporate actions:\n{bad}")
    return actions.select("ex_date", "type", "ratio").unique().sort("ex_date")


def compute_factors(actions: pl.DataFrame) -> pl.DataFrame:
    """Table (ex_date, cum_factor): factor applied to bars strictly before ex_date,
    accumulated across all LATER actions. Returned sorted by ex_date ascending."""
    a = normalize_actions(actions)
    if a.is_empty():
        return pl.DataFrame(schema={"ex_date": pl.Date, "cum_factor": pl.Float64})
    a = a.sort("ex_date", descending=True).with_columns(
        cum_factor=(1.0 / pl.col("ratio")).cum_prod()
    )
    return a.select("ex_date", "cum_factor").sort("ex_date")


def adjust_bars(bars: pl.DataFrame, actions: pl.DataFrame) -> pl.DataFrame:
    """Return split/bonus adjusted copy of `bars` (needs tz-aware `ts`).

    Factor for a bar on date d = product of (1/ratio) over actions with ex_date > d.
    Bars on/after the ex-date are untouched. Action counts are small, so a loop over
    actions with vectorised column math is simple and fast enough.
    """
    a = normalize_actions(actions)
    if a.is_empty() or bars.is_empty():
        return bars
    day = pl.col("ts").dt.date()
    factor = pl.lit(1.0)
    for ex_date, ratio in zip(a["ex_date"], a["ratio"], strict=True):
        factor = factor * pl.when(day < ex_date).then(1.0 / ratio).otherwise(1.0)
    return (
        bars.with_columns(_f=factor)
        .with_columns(
            pl.col("open") * pl.col("_f"),
            pl.col("high") * pl.col("_f"),
            pl.col("low") * pl.col("_f"),
            pl.col("close") * pl.col("_f"),
            pl.col("volume") / pl.col("_f"),
        )
        .drop("_f")
    )
