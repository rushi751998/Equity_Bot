"""Exchange-anchored resampling (no lookahead).

Bars are labelled by start time. Buckets are anchored at the session open (09:15), so 60m
bars start 09:15, 10:15, ..., 14:15 and the final bar 15:15-15:30 is 15 minutes long.
Aggregation: open=first, high=max, low=min, close=last, volume=sum.
"""

from __future__ import annotations

from datetime import datetime, time

import polars as pl

from tfalgo.calendar import timeframe_minutes

OUT_COLUMNS = ["ts", "open", "high", "low", "close", "volume", "bar_end", "n_bars"]


def resample(
    df: pl.DataFrame,
    timeframe: str,
    base_minutes: int = 5,
    session_open: time = time(9, 15),
    session_close: time = time(15, 30),
    tz: str = "Asia/Kolkata",
) -> pl.DataFrame:
    """Resample fine bars (start-labelled, tz-aware) to `timeframe`.

    Returns columns ts, open, high, low, close, volume, bar_end, n_bars.
    ``bar_end = min(ts + tf, session close)``; use :func:`visible_at` to apply the
    completed-bar rule.
    """
    open_min = session_open.hour * 60 + session_open.minute
    sess_len = (session_close.hour * 60 + session_close.minute) - open_min
    tf_min = timeframe_minutes(timeframe, sess_len)
    if tf_min < base_minutes:
        raise ValueError(f"Cannot resample {base_minutes}m bars to finer {timeframe}")
    if timeframe != "1D" and tf_min % base_minutes != 0:
        raise ValueError(f"{timeframe} is not a multiple of base {base_minutes}m")
    if df.is_empty():
        return pl.DataFrame(schema={**{c: pl.Float64 for c in OUT_COLUMNS}, "ts": df.schema["ts"],
                                    "bar_end": df.schema["ts"], "n_bars": pl.UInt32})

    local = pl.col("ts").dt.convert_time_zone(tz)
    mins = (local.dt.hour().cast(pl.Int64) * 60 + local.dt.minute().cast(pl.Int64)) - open_min
    # Special sessions (e.g. Diwali Muhurat) and any out-of-session bars are ignored (spec 2).
    work = (
        df.sort("ts")
        .with_columns(
            pl.col("ts").dt.convert_time_zone(tz),
            _day=local.dt.date(),
            _mins=mins,
        )
        .filter((pl.col("_mins") >= 0) & (pl.col("_mins") < sess_len))
        .with_columns(_bucket=pl.col("_mins") // tf_min)
    )
    out = (
        work.group_by(["_day", "_bucket"], maintain_order=True)
        .agg(
            pl.col("ts").first().alias("_first_ts"),
            pl.col("_mins").first().alias("_first_mins"),
            pl.col("open").first(),
            pl.col("high").max(),
            pl.col("low").min(),
            pl.col("close").last(),
            pl.col("volume").sum(),
            pl.len().cast(pl.UInt32).alias("n_bars"),
        )
        .with_columns(
            ts=pl.col("_first_ts")
            - pl.duration(minutes=pl.col("_first_mins") - pl.col("_bucket") * tf_min),
            _len=pl.min_horizontal(pl.lit(tf_min), pl.lit(sess_len) - pl.col("_bucket") * tf_min),
        )
        .with_columns(bar_end=pl.col("ts") + pl.duration(minutes=pl.col("_len")))
        .select(OUT_COLUMNS)
    )
    return out


def visible_at(bars: pl.DataFrame, now: datetime) -> pl.DataFrame:
    """Completed-bar rule: keep only bars with bar_end <= now (`now` must be tz-aware)."""
    if now.tzinfo is None:
        raise ValueError("`now` must be timezone-aware")
    return bars.filter(pl.col("bar_end") <= now)
