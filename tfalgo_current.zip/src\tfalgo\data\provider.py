"""Pluggable, broker-agnostic data provider interface.

Implement `DataProvider` for any vendor (Kite, Upstox, Dhan, CSV, ...) and register it with
`PROVIDERS`. The engine/strategy never import a concrete provider.

Returned bar frames: columns ``ts`` (tz-aware, bar START time), open, high, low, close, volume.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date

import polars as pl

from tfalgo.registry import Registry


@dataclass(frozen=True)
class Instrument:
    symbol: str
    isin: str | None = None
    exchange: str = "NSE"
    sector: str | None = None


class DataProvider(ABC):
    """Abstract market-data source."""

    name: str = "abstract"

    @abstractmethod
    def list_instruments(self) -> list[Instrument]: ...

    @abstractmethod
    def get_ohlcv(
        self, symbol: str, timeframe: str, start: date, end: date, adjusted: bool = False
    ) -> pl.DataFrame:
        """Bars with start date <= ts.date <= end (inclusive)."""

    @abstractmethod
    def get_corporate_actions(self, symbol: str, start: date, end: date) -> pl.DataFrame:
        """Columns: ex_date (Date), type ('split'|'bonus'), ratio (new shares per old share)."""

    @abstractmethod
    def get_index_ohlcv(self, index: str, timeframe: str, start: date, end: date) -> pl.DataFrame: ...

    def native_timeframe(self, symbol: str) -> str:
        """Finest timeframe available for the symbol (used for graceful degradation)."""
        return "5m"


PROVIDERS: Registry[DataProvider] = Registry("data provider")
