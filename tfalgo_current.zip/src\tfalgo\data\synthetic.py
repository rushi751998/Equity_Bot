"""Synthetic market data for tests/smoke runs. NOT real data; never use for conclusions."""

from __future__ import annotations

from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

import numpy as np
import polars as pl

IST = ZoneInfo("Asia/Kolkata")


def make_intraday_5m(
    start: date,
    n_days: int,
    seed: int = 0,
    start_price: float = 100.0,
    drift: float = 0.0,
    vol: float = 0.0015,
    base_volume: int = 10_000,
    holidays: set[date] | None = None,
) -> pl.DataFrame:
    """Random-walk 5m bars (75/day, 09:15-15:25 starts) on weekdays, tick-rounded to 0.05."""
    rng = np.random.default_rng(seed)
    holidays = holidays or set()
    rows: list[tuple[datetime, float, float, float, float, float]] = []
    price, d = start_price, start
    days = 0
    while days < n_days:
        if d.weekday() < 5 and d not in holidays:
            t0 = datetime.combine(d, time(9, 15), tzinfo=IST)
            for i in range(75):
                o = price
                r = rng.normal(drift, vol)
                c = o * (1 + r)
                hi = max(o, c) * (1 + abs(rng.normal(0, vol / 2)))
                lo = min(o, c) * (1 - abs(rng.normal(0, vol / 2)))
                q = lambda x: round(round(x / 0.05) * 0.05, 2)  # noqa: E731
                o, hi, lo, c = q(o), q(hi), q(lo), q(c)
                hi, lo = max(hi, o, c), min(lo, o, c)
                v = float(int(base_volume * rng.uniform(0.5, 1.5)))
                rows.append((t0 + timedelta(minutes=5 * i), o, hi, lo, c, v))
                price = c
            days += 1
        d += timedelta(days=1)
    return pl.DataFrame(
        rows, schema=["ts", "open", "high", "low", "close", "volume"], orient="row"
    ).with_columns(pl.col("ts").dt.convert_time_zone("Asia/Kolkata"))
